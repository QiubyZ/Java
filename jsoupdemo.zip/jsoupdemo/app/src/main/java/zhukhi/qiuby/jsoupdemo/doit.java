package zhukhi.qiuby.jsoupdemo;

interface doit {
}
